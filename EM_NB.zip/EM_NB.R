#To remove previous objects stored in R environment
rm(list=ls(all=TRUE)) 

#sets R's working directory to near where my files are
# setwd("D:/Backup/INSOFE/Class/CPEE/Batch-27/CSE7306c/Lab02/R/TClas")
setwd("F:/Insofe/AI/NB/Lab/R/TClas")

#Load the below  libraries 
library(tm) 
library(magrittr)

docs <- Corpus(DirSource("./speeches/"), 
               readerControl = list(reader=readPlain)) 

show(docs)
summary(docs)
meta(docs)

# Checking one document
docs[[1]]


# A character representation of a document is available via as.character()
viewDocs <- function(d, n) {d %>% extract2(n) %>% as.character() %>% writeLines()}
docs %>% extract2(1)
viewDocs(docs,1)

# Performing text processing steps:
# Stip any numbers from a text document
docs <- tm_map(docs, removeNumbers)
viewDocs(docs,1)

# Remove punctuation marks from a text document
docs <- tm_map(docs, removePunctuation)
viewDocs(docs,1)

# removes extra spaces from a text document
docs <- tm_map(docs , stripWhitespace)

#Convert into lower case 
docs <- tm_map(docs, content_transformer(tolower))

# Remove a set of words from a text document
docs <- tm_map(docs, removeWords, stopwords("english")) 

#Stem words in a text document using Porter's stemming algorithm
docs <- tm_map(docs,stemDocument, language ="english")

#Constructs or coerces to a document-term matrix
dt_matrix <-DocumentTermMatrix(docs, 
                               control=list(weighting=weightTfIdf, 
                                            minWordLength=2, 
                                            minDocFreq=5)) 

dt_matrix
inspect(dt_matrix[1:2,1:10])

# Remove sparse terms from a document-term matrix
dt_matrix <- removeSparseTerms(dt_matrix, 0.75)

#Display detailed information on a document-term matrix
inspect(dt_matrix[1:2,1:5])

dim(dt_matrix)

# Data Preparation for Classification Model:
#Store  document-term matrix in a separate data object
matrix = data.frame(as.matrix(dt_matrix))

#Construct a class variable with levels 1, 2 for Kalam and Pranab respectively
Target = as.factor(c(rep(1,12), rep(2,12)))
data = cbind(matrix, Target)

#Dividing data into train and test
data_train=data.frame(rbind(data[1:9,],data[13:21,]))
data_test=data.frame(rbind(data[10:12,],data[22:24,]))
table(data_train$Target)
table(data_test$Target)

# KNN Classification:
library(class)
pred=knn(data_train, data_test, data_train$Target, k = 1)

#Classification table with test data
conf.mat=table(pred,data_test$Target)
library(caret)
confusionMatrix(data = pred,reference = data_test$Target)
# Checking the accuracy
accuracy <- sum(diag(conf.mat))/nrow(data_test) * 100
sprintf("The accuracy of the model is %0.2f", accuracy)

# Applying Naive Bayes
library(e1071)

model = naiveBayes(Target~., data = data_train)
pred = predict(model, data_test)
head(model$tables)

str(model)


#Classification table with test data
conf.nb = table(pred, data_test$Target)
accuracy.nb <- sum(diag(conf.nb))/nrow(data_test) * 100
sprintf("The accuracy of the model using naive bayes is %0.2f", accuracy.nb)

